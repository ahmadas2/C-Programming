/****************************************************************************
 * Project number: Project 5 
 * 
 * Programmer: Ali S Ahmad
 *
 * Due Date: 11/03/2016
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: Outputs the reliability of different circuit configs 
 *
 * Inputs: SEED, TRIALS, RELIABILITY 
 *
 * Output: Reliability in series and paralelle configurations  
 *
 *
 ***************************************************************************/

#include <stdio.h> 
#include <stdlib.h>
#include <math.h>
#define max RAND_MAX

// ************* PROTOTYPE BEGINNING **************** // 

void get_input(double *, int *, unsigned int *); // function that gets numbers and adds rules 
void put_output(double, double, int, double, double); // the output after rules have been added 
double rand_float(double, double); //generates the random numbers required 


void print_heading(){
	char name[32] = "Ali S Ahmad";
	printf("%s\n", name);
	printf("Programming with C \(EGRE 245) Fall 2016");
	printf("\nProgramming Project 5 \n");
	printf("Instrumentation Reliability \n");
}

double rand_float(double low, double high){

double alpha = ((double)rand()/ RAND_MAX)*(high - low ) + low;
return alpha;

}

int main(){
	//Delcaring neccesarry variables
	 
	double reli= 0.0;
	int trials = 0;
	unsigned int seed = 0; 
	
	print_heading(); //prints header obviously
	/* LINE COUSHIN */ printf("\n\n"); /* LINE COUSHIN */
	
	
	get_input(&reli, &trials,&seed); //gets inputs from user 
	srand(seed); // randomizes using seed
	
	
	
	double works = 0.0;
	double workp = 0.0;
	double comps = 0.0;
	double compp = 0.0; 
	

	for (int i =1; i <= trials; i++)
	{
		
		double a = rand_float(0,1);
		double b = rand_float(0,1);
		double c = rand_float(0,1);
		
		//checking reiability in LL v. S config.
		if ( a < reli && b < reli && c < reli){
			comps++;
			}
		if ( a < reli || b < reli || c < reli){
			compp++;
			}
	
	}
		works = (double)comps/(trials); // calculates reliability in series
		workp = compp/(trials);         // calculates reliability in paralelle
		//printf("\n%0.3lf \t %0.3lf \n",works,workp);
		
		double s = reli * reli * reli; 
		double p = (3 * reli - (3 * (reli * reli)) + reli * reli * reli);
		put_output(s,p,trials,works,workp);
		return 0;
}


//print out the variables calculated 
	
void put_output(double s, double p, int trials, double works, double workp){

	printf("Analytical reliability: \n");
	printf("Series:   %.3f  Parallel:   %.3f\n",s,p);
	printf("\n");
	printf("Simulation reliability, %d trials\n",trials);
	printf("Series:   %.3f  Parallel:   %.3f\n",works, workp);
}



void get_input(double *reli, int *trials, unsigned int *seed){
	printf("Enter individual component reliability: ");
	scanf("%lf",reli); // gets individual reliability
	printf("Enter in the number of trials: ");
	scanf("%d",trials); //sets number of trials 
	printf("Enter in the unsigned integer seed: ");
	scanf("%u",seed);
}
