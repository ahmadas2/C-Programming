/****************************************************************************
 * Project number: Lab 7 
 *
 * Programmer: Ali S Ahmad
 *
 * Due Date: 10/27/2016
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: switches variables around 
 *
 * Inputs: X and Y variables
 *
 * Output: X and Y swapped 
 *
 *
 ***************************************************************************/


#include <stdio.h> 

void print_heading(){
	char name[32] = "Ali S Ahmad";
	printf("%s\n", name);
	printf("Programming with C \(EGRE 245) Fall 2016");
	printf("\nProgramming Lab 7\n");
	printf("Structured Programming using Functions\n");
}

void swap(double *, double *); // prototype 

int main(){
	double x = 1.23;		// declares and assigns value to variable
	double y = 4.56;		//declares and assigns value to variable 
	print_heading();
	printf("\n Before the Swap");
	printf("\n \t 1st variable before the swap = %0.3lf", x);
	printf("\n \t 2nd variable before the swap = %0.3lf", y);
	
	printf("\n\n");
	
	swap(&x,&y);
	
	printf("\n After the Swap");
	printf("\n \t 1st variable after the swap = %0.3lf", x);
	printf("\n \t 2nd variable after the swap = %0.3lf", y);
	
	return 0;
} 

void swap(double *x, double *y){
		// i mean this just flips stuff around (swaps them) 
		double temp = *x; 
		*x=*y;
		*y=temp;
		
}
