/****************************************************************************
 * Project number: Lab5a
 *
 * Programmer: Ali Ahmad
 *
 * Due Date:  10 - 6 - 2016
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: Print sideway triangle
 *
 * Inputs: i, j, x, k.
 *
 * Output: Sideway triangle made of "*"
 *
 ***************************************************************************/
#include <stdio.h>
#define ROWS 10
int main()
{
 int i, j, x, k;
 
 for (i = 0; i < ROWS; i++){
	printf("\t");
	for (j = 0; j < i; j++){
	printf("*");
	}
	printf("\n");
 }
 //decrement part
 x = ROWS;
 while(x!=0){
	 printf("\t");
	 k = x;
	 while (k > 0){
		 printf("*");
		 k--;
	 }
	 printf("\n");
	 x--;
 }
 
 return 0;
}
