/****************************************************************************
 * Program 7: driver.c - state machine scaffolding
 *
 * Programmer: Ali Ahmad
 *
 * Due Date: December 8, 2016
 *
 * EGRE 245 Fall 2016
 *
 * I pledge I neither gave nor received unauthorized aid on this program.
 *
 * Description: Gets input file from user and looks for string FSM and returns line and column number of string 
 *
 * Inputs: File name (from user) , file content (from file to functions)
 *
 * Output: Location of FSM and if it was found or not (location in line and column number)
 *
 ***************************************************************************/
#include <stdio.h>
#include <string.h>

#define MAXCHAR	256

int find_TLA(char search[], char match[]); /* prototype of search function */
void print_heading(); 
void main(void)
{
	char search[MAXCHAR];
	char match[] = {"FSM"};
	int col, line = 0, length, i;
	FILE *fp;
	char filename[269]="";
	char fline[MAXCHAR]="";
	print_heading();
	printf("\n");
	printf("Program 7 state machine that can match a TLA:\n");
	/* OPENS FILE && MAKES SURE IT EXISTS AND NOT EMPTY */
	do{
		printf("\nEnter Input Filename: ");
		scanf("%s",&filename); // gets file name from user 
		fp=fopen(filename,"r"); // searches for file and opens it in read only form 
		if(fp==NULL){
			printf("\nERROR: file %s cannot be opened!",filename); // if file does not exist or cant be open outputs this 
			}
		} 
		while(fp==NULL);
	
	while (fgets(fline, MAXCHAR, fp) != NULL){
		if (fline[strlen(fline)-1] == '\n')
				fline[strlen(fline)-1] = '\0';
			strcpy(search, fline); 
			line++;  
			col = find_TLA(search, match);
			if(col != -1) {
				printf("%s\n", search);
				printf("\t\t%s found (line %d column %d)\n", match, line, col); // prints out if FSM is found w/ its col line 
					}  
			else {
				printf("%s (%s not found)\n", search, match); // prints out if FSM was not found 
					}
			}
	fclose(fp); // closes file 
}	
 void print_heading(){
 	char name[32] = "Ali Ahmad";
	printf("%s\n", name);
	printf("EGRE 245 Fall 2016\n");
	printf("Project 7\n");
}
