#include<stdio.h>
#include<string.h>

int find_TLA( char search[], char match[] );
enum machine_state {State_0, State_1, State_2}curr;

int find_TLA( char search[], char match[] ){
	char c1 = match[0]; //F
	char c2 = match[1]; //S
	char c3 = match[2]; //M
	int col, next = 0; // declares variables 
	int len = strlen(search); //line length = length of file  
	char letter;
	int TLA_Found = 0;
	enum  machine_state curr = State_0;
	
	int i = 0;
	while ( i<len && TLA_Found!=1)
	{
		letter = search[i]; // SEARCHES FOR LETTER 
	switch(curr) {
		/* Looks for letters FSM and if doesnt get found goes back to beggining */
		case State_0:
			if(letter == c1 ){ // checks for F 
			col=i;    
			curr=State_1;
			}
			break;
		case State_1:
			if(letter == c2 ){ // checks for S
			curr=State_2;
			col=i-1;
				}
			else if(letter == c1){
			curr=State_1;
			col=i-1;
				}
			break;
		case State_2:
			if(letter == c3 ){ // checks for M
				col=i-1;
				TLA_Found =1;
					}
			else if(letter == c3){
				curr=State_1;
				col=i-1;
					}
			break;
			
		default:
			printf("Defalult");
			break;
			
			}
			i++;
		}
	if ( TLA_Found == 1){
		return col; // return that it was found and gives column number 
			}
	if(TLA_Found==0){
	return -1; // will return that it is not found
		}
	
	
}

