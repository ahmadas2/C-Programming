
/****************************************************************************
* Lab 9 � Instrumentation Reliability
*
* Programmer: Ali Ahmad
*
* Due Date: 11/03/2016
*
* EGRE 245 Fall 2016
*
* I pledge I have neither given nor received unauthorized aid on the program.
*
* Description: Gives a menu and reads in options
*
* Inputs: = Options 
*
* Outputs: = paramaters based off of options 
*
***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define true 1 
#define false 2

void print_heading();
int main()
{
	int choice;
	int done = false; 
	print_heading();
	while(done == false){
		
	printf("Select the desired operation: \n\n");
	printf("\t0 - Enter list of numbers\n");
	printf("\t1 - Find the smallest number\n");
	printf("\t2 - Find the largest number\n");
	printf("\t3 - Find the mean (average) of the numbers\n");
	printf("\t4 - Find the standard deviation from the mean\n");
	printf("\t5 - Reverse the list of numbers\n");
	printf("\t6 - Rotate the list of numbers to the right\n");
	printf("\t7 - Rotate the list of numbers to the left\n");
	printf("\t8 - Exit the program\n");
	do {
		printf("Choice?");
		fflush(stdin);
		} while(scanf("%d", &choice) < 1);
		
	switch(choice){
		case 0:
		printf("Your choice is %d\n", choice);
		break; 
		case 1:
		printf("Your choice is %d\n", choice);
		break; 
		case 2:
		printf("Your choice is %d\n", choice);
		break; 
		case 3:
		printf("Your choice is %d\n", choice);
		break; 
		case 4:
		printf("Your choice is %d\n", choice);
		break; 
		case 5:
		printf("Your choice is %d\n", choice);
		break; 
		case 6:
		printf("Your choice is %d\n", choice);
		break; 
		case 7:
		printf("Your choice is %d\n", choice);
		break; 
		case 8:
		printf("Good Bye\n");
		done = true; 
		break; 
		default: 
		printf("Illegal Choice\n");
		break;
				}
	}
 
	
}

 void print_heading() /* implement print header */{
 	char name[32] = "Ali Ahmad";
	printf("%s\n", name);
	printf("EGRE 245 Fall 2016\n");
	printf("Project 5\n");
	printf("Lab 9\n\n");
}
