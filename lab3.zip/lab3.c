/****************************************************************************
 * Project number: Lab3
 *
 * Programmer: Ali S Ahmad
 *
 * Due Date: 09/22/2016
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: Calculates the Slope intercept form of a few points 
 *
 * Inputs: str , i 
 *
 * Output: capital str , backwards capital str, and decimal value of i
 *
 * 
 ***************************************************************************/
#include <string.h>
#include <ctype.h>
#include <stdio.h>
#define SYMB 32
int main(){

char str[SYMB]; 
printf("1. Enter the characters 'c0ffee'' and print in UPPER case:");
scanf("%s", str);   
                                                     // we set the entered string into the array hello


//PART 1 
printf("	Upper case sting is: ");
for(int i = 0; i < strlen(str); i++)
{
		str[i] = toupper(str[i]);
		printf("%c", str[i]);
}

printf("\n2. Upper case characters '%s'",str);
printf("\n");
//PART 2
printf("	Print Backwards as: "); 
for (int i = strlen(str); i >= 0; i--){
		printf ("%c", str[i]);
		
}
printf("\n"); 

//PART 3
int i = 0;
printf("3. Enter the hex decimal value 'c0ffee' to print its decimal value: ");
scanf("%x", &i);
printf("	Hexidecimal value %X is equal to decimal %d\n", i,i); 
return 0;
}
