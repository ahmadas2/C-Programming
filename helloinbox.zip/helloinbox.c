/****************************************************************************
 * Project number: 1 
 *
 * Programmer: Ali S Ahmad
 *
 * Due Date: 09/08/16
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: IDK
 *
 * Inputs: 
 *
 * Output: hello world in box
 *
 ***************************************************************************/
#include <stdio.h>

int main(){
printf("+------------+ \n");
printf("|Hello world!| \n");
printf("+------------+ \n");

return 0;
}
