/****************************************************************************
 * Project number: 1 
 *
 * Programmer: Ali S Ahmad
 *
 * Due Date: 09/08/16
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: IDK
 *
 * Inputs: 
 *
 * Output: VCU in a box
 *
 ***************************************************************************/
#include <stdio.h>

int main(){
printf("  ___     ___ _________   ____ ____ ");
printf("  \\  \\ /   /\\_  __  \\|    |    \\    \n");
printf("   \\  Y   / /   \\  \\/|    |    /    \n"); 
printf("    \\    /  \\    \\___|    |   /     \n");
printf("     \\__/    \\_____  /_______/      \n");
printf("                   \\/               \n");

return 0;
}
