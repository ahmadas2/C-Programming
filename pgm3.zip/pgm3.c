/**************************************************************************
* Project: pgm3.c - simulating a falling object
*
* Programmer: Ali Ahmad 
* Due Date: 08/06/16
* 
*EGRE 245: Fall 2016
*
*I pledge I neither gave nor received unauthorized aid on this program.
*
* Description: Calculates time for object to fall x feet and its speed in MPH and FPS 
*
* Inputs: initial height (y)
*
* Output: time(t), impact velocity in FPS and MPH
*
***************************************************************************/


#include <stdio.h>
#define g 32.2


int main(){

	double y, t, v;
	//double dt = 0.00000001;
	//double g = 32.2; 
	double fim = 5280; //feet in a mile 
	double dt = 0.00000001; //change of time every loop cycle 
	double gdt = g * dt;
 
	printf("Program to calculate fall time and impact speed of\n"
       	       "a falling object dropped from a specific height.\n\n"
               "Enter initial height in feet: ");

	scanf("%lf", &y);

	for (t = 0; y >= 0; t += dt){
		//y = y - v*0.00000001;
		//v += 0.000000322;
		  y-= v * dt;
		  v+= gdt; // increases the vilocety by the interval given above 
	}

	double fps2mph = (v*(3600))/fim; // converts feet per seconds to miles per hour 

	printf("\nFalling time = %lf sec\n"
               "Impact speed = %lf feet/second\n" 
               "Impact speed = %lf miles/hour\n", t, v, fps2mph);

	return 0; 

}
