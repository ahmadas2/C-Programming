/****************************************************************************
 * Project number: Lab 8 
 * 
 * Programmer: Ali S Ahmad , Richard Robinson
 *
 * Due Date: 11/03/2016
 *
 * EGRE 245 Fall 2016
 *
 * Pledge: I have neither given nor received unauthorized aid on the program.
 *
 * Description: Outputs the reliability of different circuit configs 
 *
 * Inputs: size, array values, x 
 *
 * Output: solution to plynomial 
 *
 *
 ***************************************************************************/
#include <stdio.h>
#include <math.h>
#include <stdlib.h>
void solvePoly(double *);
void solvePoly2(double [], int , double );
int main() {
	int size = 6;
	double arr[6] = {-6,7,-1,-5,2,3};
	double arr2[6] = {4,-2,0,3,0,0}; 
	double x = 3.123; 
	solvePoly(&x);
	solvePoly2(arr,size,x);
	solvePoly2(arr2,size,x);
}

void solvePoly(double *x){
	double value = *x;
	double power5 = pow(value,5);
	double power4 = pow(value,4);
	double power3 = pow(value,3);
	double power2 = pow(value,2);
	double answer = (3*power5)-(2*power4)-(5*power3)-(power2)+(7*(value))-6; 
	printf("Function solvePoly\n\t given x= %0.3lf returns: %0.3lf\n",value, answer);
}

void solvePoly2(double arr[], int size, double x){
	double value = 0; 
	printf("\nFunction solvePoly2 \n \t given coefficients:");
	for(int i = 0; i < size ; i++){
		value += arr[i] * pow(x,i);
		printf("%0.0lf ",arr[i]);		
	}
	printf("\n\t and x =%0.3lf\n\t returns: %0.3lf\n",x,value);
	
}
