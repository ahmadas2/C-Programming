/****************************************************************************
* Lab 10 – arrays of pointers
*
* Programmer: Ali Ahmad
*
* Due Date: 11/24/16
*
* EGRE 245 Fall 2016
*
* I pledge I neither gave nor received unauthorized aid on this program.
*
* Description:  processes an array of strings
*
* Inputs: Array of FG arr
*
* Output: Array number, address, string addres and size and address
*
***************************************************************************/
#include<stdio.h>
#include<string.h>
#include<malloc.h>
#define SIZE 7

void prt_arr_array(char**, int);
void shut_up_meg(char**, int);
void print_heading();
void print_heading() 
{
 char name[32] = "Ali S Ahmad";
 printf("%s\n", name);
 printf("EGRE-245-002-2016Fall\n");
 printf("Programming Lab 10\n ");
 printf("Arrays of Pointers\n\n");
}

int main(){
	char *arr[SIZE];
	
	arr[0]="Chris";
	arr[1]="Lois";
	arr[2]="Meg";
	arr[3]="";
	arr[4]="";
	arr[5]="Peter";
	arr[6]="Stewie";
	
	print_heading();
	
	printf("The size of a char is 1 and the size of a char* is 4\n");
	printf("\nDeclared, Defined, and Initialized 7 element array\n");
	prt_arr_array(arr, SIZE);
	
	printf("\nNow add string values to the third and fourth arry elements\n");
	printf("\nUpdated 7 element array with complete information\n");
	
	arr[3]=malloc(strlen(arr[2]));
	strcpy(arr[3], "Meg");
	arr[4]=malloc(strlen ("Brian")+1);
	strcpy(arr[4], "Brian");
	prt_arr_array(arr, SIZE);
	
	printf("\nRemove Strings equal to \"Meg\"\n");
	shut_up_meg(arr, SIZE);
	shut_up_meg(arr, SIZE);
	prt_arr_array(arr, SIZE);
}

void prt_arr_array(char** arr, int num) {
int length;
	for(int i=0;i<SIZE;i++){
	length = strlen(arr[i]);
	printf("arr[%d] is add %x string addr %x contains %d bytes %s\n",i,&arr[i],arr[i],length,arr[i]);
	}
}

void shut_up_meg(char** arr, int num) {

	for(int i=0;i<SIZE;i++){
	 if(strcmp(arr[i],"Meg")==0){
		for(int j = i;j<SIZE;j++){
			if(j==SIZE-1)
			arr[j]="";	
		else
			arr[j]=arr[j+1];
			}
		 }
	}
}
