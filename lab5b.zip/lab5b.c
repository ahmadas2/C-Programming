/**************************************************************************
* Project: Lab5B
*
* Programmer: Ali Ahmad 
* Due Date: 10/06/16
* 
*EGRE 245: Fall 2016
*
*I pledge I neither gave nor received unauthorized aid on this program.
*
* Description: Prints alphabet in x pattern 
*
* Inputs: i,j
*
* Output: alphabet in x pattern a-z and z-a 
*
***************************************************************************/
#include <stdio.h>
#define rows 26
#define col 26 

int main (){
for (int i = 0; i < rows; i++){
printf("\t");
for (int j = 0; j < col; j++){
	if(i == j){
	printf("%c",'A'+i);
	}
	else if(j == rows-1-i){
	printf("%c",'Z'-i);
	} 
	else{
	printf(" ");
	}
}
printf("\n");
}
}
