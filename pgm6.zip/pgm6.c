
/****************************************************************************
* Project 6 Arrays
*
* Programmer: Ali Ahmad
*
* Due Date: 11/17/2016
*
* EGRE 245 Fall 2016
*
* I pledge I have neither given nor received unauthorized aid on the program.
*
* Description: Gives a menu and reads in options
*
* Inputs: = Options, Double Array, Array Size 
*
* Outputs: = smallest number, largest number, mean, std dev , numbers reversed, nums shifted right, nums shifted left
*
***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define true 1 
#define false 0

void flushing_buffer(){
	int dank;
	do { 
		dank = getchar();
	}
	while (dank !='\n' && dank!=EOF); // reads to the end of the file  before continuing :) 
}
/* * * * * * * * PROTOTYPE DECLERATION * * * * * * * */ 
void print_heading();
void listofnumbers(int *,double *arr);
void smallest(int , double [] );
void largest(int , double [] );
double mean(int a,double arr[]);
void stddev(int a,double arr[]);
void reverse(int ,double *arr);
void shiftr(int ,double *arr);
void shiftl(int ,double *arr);

/* * * * * * * * * * MAIN FUNCTION * * * * * * * * * */

int main()
{
	int choice;							// declares choice 
	int done = false;
	int a = 0;   						// used for array length 
	print_heading();
	while(done == false){
/* * * * * * * * * * * * *  Options * * * * * * * * * * * * * */
	printf("Select the desired operation: \n\n");
	printf("\t1 - Enter list of numbers\n");
	printf("\t2 - Find the smallest number\n");
	printf("\t3 - Find the largest number\n");
	printf("\t4 - Find the mean (average) of the numbers\n");
	printf("\t5 - Find the standard deviation from the mean\n");
	printf("\t6 - Reverse the list of numbers\n");
	printf("\t7 - Rotate the list of numbers to the right\n");
	printf("\t8 - Rotate the list of numbers to the left\n");
	printf("\t9 - Exit the program\n");
	
	do {
		printf("Choice?");				  // Asks user for input :) 
		scanf("%d", &choice);			 //  Reads value and sets it to variable choice
		flushing_buffer();				//   Clears buffer (since it doesnt work on unix) 
		} while(choice < 1); 		   //    Error Handler (if user enters letter) 
	
	switch(choice){
		case 1:
		printf("Your choice is %d\n", choice);		
		double arr[100];
		listofnumbers(&a,arr);
		break;
		
		case 2:
		printf("Your choice is %d\n", choice);
 		smallest(a,arr);
		break; 
		case 3:
		printf("Your choice is %d\n", choice);
		largest(a,arr);
		break; 
		case 4:
		printf("Your choice is %d\n", choice);
		double m = mean(a,arr);
		printf("\nThe Average is: %0.3lf\n",m);
		break; 
		case 5:
		printf("Your choice is %d\n", choice);
		stddev(a,arr);
		break; 
		case 6:
		printf("Your choice is %d\n", choice);
		reverse(a,arr);
		break; 
		case 7:
		printf("Your choice is %d\n", choice);
		shiftr(a,arr);
		break; 
		case 8:
		printf("Your choice is %d\n", choice);
		shiftl(a,arr);
		break; 
		case 9:
		printf("Good Bye\n");
		done = true; 
		break; 
		default:
		printf("Illegal Choice\n");
		
		break;
				}
	}
 
	
}
void listofnumbers(int *a,double *arr){ // asssigns values to an array of name 
		int ae;
		printf("How many numbers? ");
		scanf("%d", &ae); 
		
		if (ae < 2 || ae > 100){       // demands input between 2 to 100 
			printf("\nThat number is not in the approperate range please enter a new number:");
			scanf("%d",&ae);
			}
		for (int i = 0; i < ae; i++){
			double j;
			printf("X[%d]= ", i);  // asks for value for each element  
			scanf("%lf",&j);      // assigning values to array elements 
			arr[i] = j;          
			//printf("\n");
		}
		printf("\nThe Array entered is: \n");
		for (int i = 0; i < ae; i++){
			printf("X[%d]= %0.3lf\n", i, arr[i]); // Prints the values assigned to each element of array
		}
		
		*a = ae;  								// assings value to variable a (used as length in proceeding functions 

}

void smallest(int a,double arr[]){

	int i=0;
	double smallest = arr[0]; //sets value to double smallest and then compares it agianst other elements in array 
	while (i < a){
		if (smallest > arr[i]){
			smallest = arr[i];
		}
		i++;
		}
		printf("\nThe Smallest Number is: %0.3lf\n",smallest);
}

void largest(int a,double arr[]){

	int i=0;
	double largest = arr[0]; // sets value to double largest and then compares it agianst other elements in array 
	while (i < a){
		
		if (largest < arr[i]){
			largest = arr[i];
		}
		i++;
		}
		printf("\nThe Largest Number is: %0.3lf\n",largest);
}
double mean(int a,double arr[]){
	double avg;
	int i=0;
	double sum = 0;
	while (i < a){
		sum += arr[i]; // adds values of elements to sum
		i++;
		}
		avg = sum / a; //divides sum by the length of array and sets it to avg
		return avg; //returns mean
}
void stddev(int a,double arr[]){
	double m2 = mean(a,arr); // sets the mean to double m2 
	int i=0;
	double sum = 0;
	double b;
	while (i < a){
		b = arr[i] -  m2; 	 //subtracts mean from each element 
		b *= b; 			// squares elememnts 
		sum += b;          // adds them to sum 
		i++;
		}
		sum /= (a-1);   
		double stdv = sqrt(sum); // gets standard deviation value
	printf("\nThe Standard Deviation is: %0.3lf\n",stdv);
}
void reverse(int a,double *arr){
	int s = 0; //starts at begginning of array
	int e = a-1; //starts at end of array
	double temp;
    while (s < e)
    {	/* * * reverses elements of array * * */
        temp = arr[s];   
        arr[s] = arr[e];
        arr[e] = temp;
        s++;
        e--;
    }
    printf("Array is: now\n");
	for (int i = 0; i < a; i++){
	   printf("X[%d] = %0.3lf\n",i,arr[i]);
   }
}
void shiftr(int a,double *arr){  //SHIFTS ARRAY VALUES RIGHT 
	double temp = arr[a-1];
	int i = (a-1);
	while (i > 0){
		arr[i] = arr[i-1];
		i--;
	}
	arr[0] = temp;
	printf("Array is: now\n");
	for (int i = 0; i < a; i++){
		printf("X[%d] = %0.3lf\n",i,arr[i]);
	}
}
void shiftl(int a,double *arr){ //SHIFTS ARRAY VALUES LEFT
	double temp = arr[0];
	int i = 0;
	while (i < a-1){
		arr[i] = arr[i+1];
		i++;
	}
	arr[a-1] = temp;
	printf("Array is: now\n");
	for (int i = 0; i < a; i++){
		printf("X[%d] = %0.3lf\n",i,arr[i]);
	}
}
 void print_heading() /* implement print header */{
 	char name[32] = "Ali Ahmad";
	printf("%s\n", name);
	printf("EGRE 245 Fall 2016\n");
	printf("Project 5\n");
	printf("Lab 9\n\n");
}

