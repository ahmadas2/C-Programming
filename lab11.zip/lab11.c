/****************************************************************************
* Lab 11 from infile to outfile 
*
* Programmer: Ali Ahmad
*
* Due Date: 11/17/2016
*
* EGRE 245 Fall 2016
*
* I pledge I have neither given nor received unauthorized aid on the program.
*
* Description: Gives a menu and reads in options
*
* Inputs: = filename.txt
*
* Outputs: = file with writing from first file 
*
***************************************************************************/


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define SIZE 200
void print_heading();



int main(){
	 FILE *fp = NULL;
	 char str[999];
	 char fname[SIZE];
	
	 print_heading() ;
	 while ( fp == NULL){
	 printf("enter file name: ");	
	 scanf("%s",fname); 
	 fp = fopen(fname, "r");
	 if ( fp == NULL){ 
		 printf("\nBad File Try Again\n");
	 }
	}



	int len = 0;
	int line = 1;
	char name[100] = "";
	for (int i = 0 ; fname[i] != '.' && fname[i] != '\0'; i++){
		name[i] = fname [i];
	}
	strcat(name,"_out.txt");
	FILE *secondfile;
	secondfile = fopen(name,"w");

	
	line = 1;
	while (fgets(str, sizeof(str), fp)!=NULL){
		if (str[strlen(str)-1] == '\n')
		   str[strlen(str)-1] = '\0';
		len = strlen(str);
		fprintf(secondfile,"\n %d (%d) %s",line,len, str);
		printf("\n %d (%d) %s",line,len, str);
		line++;
	}
		fclose(fp);
	
}
void print_heading() 
{
 char name[32] = "Ali S Ahmad , Matthew Winders";
 printf("%s\n", name);
 printf("EGRE-245-002-2016Fall\n");
 printf("Programming Lab 11\n");
 printf("From infile to outfile \n\n");
}
