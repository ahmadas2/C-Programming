/**************************************************************************
* Project: Lab4
*
* Programmer: Ali Ahmad 
* Due Date: 09/29/16
* 
*EGRE 245: Fall 2016
*
*I pledge I neither gave nor received unauthorized aid on this program.
*
* Description: Calulculates distance travelled in time given 
*
* Inputs: t(time to hit the ground) , ed (estimated height of building)
*
* Output: d - Distances traveled over time intervals ( table ) , if/else statements comparing estimated height vs actual * * 	height
*
***************************************************************************/
#include <stdio.h>
#include <math.h>
int main(){
	float g,d,ed;
	int t;
	g=9.8; // gravity in m/s^2
	
	printf("\nEnter the falling time in seconds: ");
	scanf("%d",&t); // gets time and sets it 
	printf("\nEnter the estimation of building height in meters: "); 
	scanf("%f",&ed); // gets estimated distance and sets it 
	printf("\n");
	printf("\nTime Falling (seconds)\t\t\tDistance Fallen (meters)\n");

	for(int i = 0; i <= t; i++){ // i is symbolic to time (seconds)
		d = 0.5 * (g * (i*i)); //calculates distance fallen in time given  
		printf("\t%d\t\t\t\t\t%0.2f \n",i,d);      // prints seconds vs distance table  	
		}
	printf("\n");
	if(ed < d){
	printf("Distance fallen is greater than the estimated height of building");	
	}
	else if(ed > d){
	printf("Distance fallen is less than the estimated height of building");	
	}
	else{
	printf("Distance fallen is equal to estimated height of building");
	}  
	printf("\n");
	}
