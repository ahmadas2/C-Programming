/****************************************************************************
* Lab 11 from infile to outfile 
*
* Programmer: Ali Ahmad && Matthew Winders 
*
* Due Date: 12/08/2016
*
* EGRE 245 Fall 2016
*
* I pledge I have neither given nor received unauthorized aid on the program.
*
* Description: Gives a menu and reads in options
*
* Inputs: = Integer 
*
* Outputs: = Sum
*
***************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void print_heading();
int sum(int sum, int number);
int main(int argc, char *argv[]){
	print_heading();
	int number;
	if ( argc > 1){
		number = atoi(argv[1]);
		int s = sum(0,number);
		printf("The sum of the even numbers is: %d\n",s);
		}
	else {
		printf("No Command Line Arguments Given\n");
		printf("Enter a Number:");
		scanf("%d",&number);
		int s = sum(0,number);
		printf("The sum of the even numbers is: %d \n",s);
	}
}
int sum(int cum, int number){
	 
	 if (number == 0){
		
		return cum;
		}
	else if ( (number % 2) ==0 ) {
		cum += number;
		}
    sum(cum , number -1);
		}
void print_heading() 
{
 char name[32] = "Ali S Ahmad , Matthew Winders";
 printf("%s\n", name);
 printf("EGRE-245-002-2016Fall\n");
 printf("Programming Lab 12\n");
 printf("Calculate a sum Recursively \n\n");
}
