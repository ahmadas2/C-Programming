/**************************************************************************
* Project: dice
*
* Programmer: Ali Ahmad & John Yousef 
* Due Date: 10/13/16
* 
*EGRE 245: Fall 2016
*
*I pledge I neither gave nor received unauthorized aid on this program.
*
* Description: Rolls dice 100,000 times and outputs the nuumber of times it rolls 2,7,12 and then prints mean
*
* Inputs: seed;
*
* Output: average and num rolls of 2,7,12
*
***************************************************************************/

#include <stdio.h>
#include <stdlib.h>

/* * * * * * * * * * * Beggining of throw die * * * * * * * */

int throw_one_die(){
return rand()%6+1;
}

/* * * * * * * * * * * BEGGINING of Main * * * * * * * * * */
int main(){
int max = 100000;
int i,sum,seed;
int total = 0;
float mean; 

printf("Enter random seed value:");
scanf("%d",&seed);
srand(seed);
printf("\n");

int array[13] = {47,22,0,0,0,0,0,0,0,0,0,0,0};

for(i = 0; i < max; i++){ 
int sum = throw_one_die()+throw_one_die();
array[sum]++;
//printf("%d\n",sum);
} 

for(i=2; i < 13; i++){
total += i * array[i];
}

printf("Number of times 2 was rolled: %d\n",array[2]);
printf("Number of times 7 was rolled: %d\n",array[7]);
printf("Number of times 12 was rolled: %d\n",array[12]);
mean = ((float)total / max);
printf("The mean of all the rolls: %0.3f\n",mean);
}
